-- ================================================================
-- BeeSoftware - NORMALIZACIÓN DE TÉCNICOS
-- ================================================================
-- Este script normaliza TODOS los técnicos en la base de datos
-- para que coincidan EXACTAMENTE con los 4 técnicos válidos de Access
--
-- TÉCNICOS VÁLIDOS (definitivos):
--   1. José    (con tilde en ó, primera mayúscula)
--   2. Tadas   (primera mayúscula)
--   3. Enrique (primera mayúscula)
--   4. Deve    (primera mayúscula)
--
-- ⚠️ IMPORTANTE: Ejecuta este script MANUALMENTE desde MySQL o phpMyAdmin
-- ================================================================

USE beesoftware;

-- ----------------------------------------------------------------
-- PASO 1: Ver estado actual de los técnicos
-- ----------------------------------------------------------------
SELECT 'ANTES DE LA NORMALIZACIÓN' as Estado;
SELECT DISTINCT nombre_tecnico, COUNT(*) as cantidad
FROM partes
GROUP BY nombre_tecnico
ORDER BY nombre_tecnico;


-- ----------------------------------------------------------------
-- PASO 2: Limpiar espacios en blanco (trim)
-- ----------------------------------------------------------------
UPDATE partes
SET nombre_tecnico = TRIM(nombre_tecnico)
WHERE nombre_tecnico IS NOT NULL;


-- ----------------------------------------------------------------
-- PASO 3: Normalizar "José" (con tilde)
-- ----------------------------------------------------------------
-- Unificar todas las variantes de Jose/José a "José" (con tilde)
UPDATE partes
SET nombre_tecnico = 'José'
WHERE nombre_tecnico IN ('Jose', 'jose', 'JOSE', 'José', 'josé', 'JOSÉ');


-- ----------------------------------------------------------------
-- PASO 4: Normalizar "Tadas"
-- ----------------------------------------------------------------
-- Unificar todas las variantes de Tadas
UPDATE partes
SET nombre_tecnico = 'Tadas'
WHERE nombre_tecnico IN ('tadas', 'TADAS', 'Tadas', 'Tadas tecnico');


-- ----------------------------------------------------------------
-- PASO 5: Normalizar "Enrique"
-- ----------------------------------------------------------------
-- Unificar todas las variantes de Enrique
UPDATE partes
SET nombre_tecnico = 'Enrique'
WHERE nombre_tecnico IN ('enrique', 'ENRIQUE', 'Enrique', 'Enrique tecnico');


-- ----------------------------------------------------------------
-- PASO 6: Normalizar "Deve"
-- ----------------------------------------------------------------
-- Unificar todas las variantes de Deve
UPDATE partes
SET nombre_tecnico = 'Deve'
WHERE nombre_tecnico IN ('deve', 'DEVE', 'Deve');


-- ----------------------------------------------------------------
-- PASO 7: Limpiar valores incorrectos (OPCIONAL)
-- ----------------------------------------------------------------
-- Si hay técnicos que NO son ninguno de los 4 válidos, 
-- puedes ponerlos a NULL o dejarlos como están para revisión manual

-- Opción A: Poner a NULL los que no sean válidos
-- UPDATE partes
-- SET nombre_tecnico = NULL
-- WHERE nombre_tecnico NOT IN ('José', 'Tadas', 'Enrique', 'Deve')
--   AND nombre_tecnico IS NOT NULL
--   AND nombre_tecnico != '';

-- Opción B: Ver cuáles son los inválidos antes de decidir
SELECT 'TÉCNICOS NO VÁLIDOS ENCONTRADOS (si aparece algo aquí, revisar manualmente):' as Advertencia;
SELECT DISTINCT nombre_tecnico, COUNT(*) as cantidad
FROM partes
WHERE nombre_tecnico NOT IN ('José', 'Tadas', 'Enrique', 'Deve')
  AND nombre_tecnico IS NOT NULL
  AND nombre_tecnico != ''
GROUP BY nombre_tecnico;


-- ----------------------------------------------------------------
-- PASO 8: Normalizar tabla USUARIOS (técnicos)
-- ----------------------------------------------------------------
-- También normalizar los nombres en la tabla de usuarios
UPDATE usuarios
SET name = 'José'
WHERE username = 'jose' AND role = 'user';

UPDATE usuarios
SET name = 'Tadas'
WHERE username = 'tadas' AND role = 'user';

UPDATE usuarios
SET name = 'Enrique'
WHERE username = 'enrique' AND role = 'user';

UPDATE usuarios
SET name = 'Deve'
WHERE username = 'deve' AND role = 'user';

-- Eliminar Antonio si existe (no está en la lista de 4 técnicos válidos)
DELETE FROM usuarios
WHERE username = 'antonio' AND role = 'user';


-- ----------------------------------------------------------------
-- PASO 9: Verificar resultado final
-- ----------------------------------------------------------------
SELECT 'DESPUÉS DE LA NORMALIZACIÓN - TÉCNICOS EN PARTES' as Estado;
SELECT DISTINCT nombre_tecnico, COUNT(*) as cantidad
FROM partes
GROUP BY nombre_tecnico
ORDER BY nombre_tecnico;

SELECT '';
SELECT 'DESPUÉS DE LA NORMALIZACIÓN - TÉCNICOS EN USUARIOS' as Estado;
SELECT id, username, name, role
FROM usuarios
WHERE role = 'user'
ORDER BY name;


-- ================================================================
-- RESULTADO ESPERADO:
-- ================================================================
-- Debe mostrar SOLO estos 4 técnicos (más NULL o vacío si hay partes sin técnico):
--   - Deve
--   - Enrique
--   - José
--   - Tadas
--
-- Y en la tabla usuarios, solo deben aparecer esos 4 técnicos con role='user'
-- ================================================================
