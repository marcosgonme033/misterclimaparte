-- ===============================================
-- BeeSoftware - Añadir campo "calle" a la tabla partes
-- ===============================================
-- Este script añade el campo "calle" para almacenar la dirección completa
-- y permitir abrir Google Maps con la ubicación exacta

USE ysqytyxn_ddbbMrClimaPartes;

-- Añadir columna calle (si no existe)
-- La columna se añade después de poblacion para mantener la coherencia
ALTER TABLE partes 
ADD COLUMN IF NOT EXISTS calle VARCHAR(255) NULL 
AFTER poblacion;

-- Verificar que la columna se creó correctamente
DESCRIBE partes;

-- Información de uso:
-- Este campo permite almacenar direcciones completas como "Av. XXX 12, 3ºB"
-- En el frontend, al clicar en población se abre Google Maps con "calle, poblacion" o solo "poblacion"
