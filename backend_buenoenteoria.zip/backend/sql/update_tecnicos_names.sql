-- ===============================================
-- BeeSoftware - Actualizar nombres de técnicos
-- ===============================================
-- Este script asegura que los 4 técnicos correctos estén en la BD
-- con sus nombres exactos: José, Tadas, Enrique, Deve

USE beesoftware;

-- Verificar técnicos actuales
SELECT id, username, name, role FROM usuarios WHERE role = 'user' ORDER BY name ASC;

-- ===============================================
-- Actualizar nombres de técnicos a los correctos
-- ===============================================

-- Actualizar todos los posibles técnicos a los nombres correctos
UPDATE usuarios SET name = 'José' WHERE username IN ('jose', 'Jose') AND role = 'user';
UPDATE usuarios SET name = 'Tadas' WHERE username IN ('tadas', 'Tadas') AND role = 'user';
UPDATE usuarios SET name = 'Enrique' WHERE username IN ('enrique', 'Enrique') AND role = 'user';
UPDATE usuarios SET name = 'Deve' WHERE username IN ('deve', 'Deve') AND role = 'user';

-- Eliminar Antonio si existe (no debe estar en la lista)
-- Si Antonio es un técnico válido que debe mantenerse, comenta esta línea
DELETE FROM usuarios WHERE username = 'antonio' AND role = 'user';

-- Actualizar los nombres de técnicos en los partes existentes para que coincidan
UPDATE partes SET nombre_tecnico = 'José' WHERE nombre_tecnico IN ('Jose', 'jose', 'JOSE', 'José');
UPDATE partes SET nombre_tecnico = 'Tadas' WHERE nombre_tecnico IN ('tadas', 'TADAS', 'Tadas');
UPDATE partes SET nombre_tecnico = 'Enrique' WHERE nombre_tecnico IN ('enrique', 'ENRIQUE', 'Enrique');
UPDATE partes SET nombre_tecnico = 'Deve' WHERE nombre_tecnico IN ('deve', 'DEVE', 'Deve');


-- ===============================================
-- OPCIÓN 2: Crear técnicos si no existen
-- ===============================================
-- Descomenta estas líneas si necesitas crear los técnicos desde cero
-- IMPORTANTE: Ajusta las contraseñas según tu sistema de hash

-- INSERT INTO usuarios (username, password, name, role) VALUES
-- ('jose', 'hash_de_contraseña_aqui', 'José', 'user')
-- ON DUPLICATE KEY UPDATE name = 'José', role = 'user';

-- INSERT INTO usuarios (username, password, name, role) VALUES
-- ('tadas', 'hash_de_contraseña_aqui', 'Tadas', 'user')
-- ON DUPLICATE KEY UPDATE name = 'Tadas', role = 'user';

-- INSERT INTO usuarios (username, password, name, role) VALUES
-- ('enrique', 'hash_de_contraseña_aqui', 'Enrique', 'user')
-- ON DUPLICATE KEY UPDATE name = 'Enrique', role = 'user';

-- INSERT INTO usuarios (username, password, name, role) VALUES
-- ('deve', 'hash_de_contraseña_aqui', 'Deve', 'user')
-- ON DUPLICATE KEY UPDATE name = 'Deve', role = 'user';


-- ===============================================
-- Verificar resultado final
-- ===============================================
SELECT id, username, name, role FROM usuarios WHERE role = 'user' ORDER BY name ASC;

-- Debe mostrar exactamente:
-- | username  | name     | role |
-- |-----------|----------|------|
-- | debe      | Deve     | user |
-- | enrique   | Enrique  | user |
-- | jose      | José     | user |
-- | tadas     | Tadas    | user |
