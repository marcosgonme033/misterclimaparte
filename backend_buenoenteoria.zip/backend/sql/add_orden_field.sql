-- ===============================================
-- BeeSoftware - Script SQL para añadir campo de orden
-- ===============================================
-- Este campo permite reordenar manualmente las partes dentro de cada columna

USE beesoftware;

-- Añadir campo orden si no existe
ALTER TABLE partes 
ADD COLUMN IF NOT EXISTS orden INT NOT NULL DEFAULT 0 AFTER estado;

-- Crear índice compuesto para ordenación eficiente por estado y orden
CREATE INDEX IF NOT EXISTS idx_estado_orden ON partes(estado, orden);

-- Inicializar valores de orden para partes existentes (por fecha de creación)
SET @row_number = 0;
SET @current_estado = '';

UPDATE partes p
JOIN (
  SELECT 
    id,
    estado,
    @row_number := IF(@current_estado = estado, @row_number + 1, 1) AS new_orden,
    @current_estado := estado
  FROM partes
  ORDER BY estado, created_at DESC
) AS ranked ON p.id = ranked.id
SET p.orden = ranked.new_orden;

-- Verificar el cambio
SELECT id, numero_parte, estado, orden FROM partes ORDER BY estado, orden;
