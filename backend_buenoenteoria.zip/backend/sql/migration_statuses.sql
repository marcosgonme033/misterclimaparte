-- ===============================================
-- BeeSoftware - Migración de Estados de Partes
-- ===============================================
-- Este script migra los estados antiguos a los nuevos
-- Antiguos: inicial, revisado, visitado, reparado
-- Nuevos: inicial, revisando, visitas_realizadas, ausentes
--
-- IMPORTANTE: Ejecutar ANTES de actualizar el código del backend/frontend

USE beesoftware;

-- ============================================
-- PASO 1: Verificar estados actuales
-- ============================================
SELECT 
  estado, 
  COUNT(*) as cantidad 
FROM partes 
GROUP BY estado;

-- ============================================
-- PASO 2: Realizar la migración de estados
-- ============================================

-- Migrar 'revisado' -> 'revisando'
UPDATE partes 
SET estado = 'revisando' 
WHERE estado = 'revisado';

-- Migrar 'visitado' -> 'visitas_realizadas'
UPDATE partes 
SET estado = 'visitas_realizadas' 
WHERE estado = 'visitado';

-- Migrar 'reparado' -> 'ausentes'
UPDATE partes 
SET estado = 'ausentes' 
WHERE estado = 'reparado';

-- ============================================
-- PASO 3: Verificar la migración
-- ============================================
SELECT 
  estado, 
  COUNT(*) as cantidad 
FROM partes 
GROUP BY estado;

-- ============================================
-- PASO 4: Validar que no queden estados antiguos
-- ============================================
SELECT 
  id, 
  numero_parte, 
  estado 
FROM partes 
WHERE estado IN ('revisado', 'visitado', 'reparado');

-- Si la query anterior devuelve resultados, algo falló en la migración

-- ============================================
-- PASO 5: Recrear índice de estado (opcional pero recomendado)
-- ============================================
DROP INDEX IF EXISTS idx_estado ON partes;
CREATE INDEX idx_estado ON partes(estado);

-- ============================================
-- PASO 6: Verificar orden de partes por estado
-- ============================================
SELECT 
  id, 
  numero_parte, 
  estado, 
  orden, 
  created_at 
FROM partes 
ORDER BY 
  CASE estado
    WHEN 'inicial' THEN 1
    WHEN 'revisando' THEN 2
    WHEN 'visitas_realizadas' THEN 3
    WHEN 'ausentes' THEN 4
    ELSE 5
  END,
  orden ASC,
  created_at DESC;

-- ============================================
-- RESUMEN DE MIGRACIÓN
-- ============================================
-- ✅ 'revisado' -> 'revisando'
-- ✅ 'visitado' -> 'visitas_realizadas'
-- ✅ 'reparado' -> 'ausentes'
-- ✅ 'inicial' -> 'inicial' (sin cambios)
