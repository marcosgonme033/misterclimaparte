-- ===============================================
-- BeeSoftware - Actualizar estados de partes para Kanban
-- ===============================================
-- Este script actualiza la tabla partes para soportar los nuevos estados del tablero Kanban

USE ysqytyxn_ddbbMrClimaPartes;

-- Modificar el campo estado para incluir los nuevos valores
ALTER TABLE partes 
MODIFY COLUMN estado VARCHAR(50) NOT NULL DEFAULT 'inicial'
COMMENT 'Estados Kanban: inicial, revisado, visitado, reparado';

-- Actualizar partes existentes con estado 'pendiente' a 'inicial'
UPDATE partes 
SET estado = 'inicial' 
WHERE estado = 'pendiente' OR estado NOT IN ('inicial', 'revisado', 'visitado', 'reparado');

-- Verificar los estados actuales
SELECT estado, COUNT(*) as cantidad 
FROM partes 
GROUP BY estado;
