-- =============================================
-- SCRIPT RÁPIDO - Actualizar técnicos
-- =============================================
-- Copia y pega estas líneas en phpMyAdmin o MySQL Workbench

USE ysqytyxn_ddbbMrClimaPartes;

-- 1. Ver técnicos actuales
SELECT username, name, role FROM usuarios WHERE role = 'user';

-- 2. Actualizar nombres en tabla usuarios (los 4 técnicos correctos)
UPDATE usuarios SET name = 'José' WHERE username = 'jose' AND role = 'user';
UPDATE usuarios SET name = 'Tadas' WHERE username = 'tadas' AND role = 'user';
UPDATE usuarios SET name = 'Enrique' WHERE username = 'enrique' AND role = 'user';
UPDATE usuarios SET name = 'Deve' WHERE username = 'deve' AND role = 'user';

-- 3. Eliminar Antonio si existe
DELETE FROM usuarios WHERE username = 'antonio' AND role = 'user';

-- 4. Actualizar nombres en PARTES para que coincidan
UPDATE partes SET nombre_tecnico = 'José' WHERE nombre_tecnico IN ('Jose', 'jose', 'JOSE');
UPDATE partes SET nombre_tecnico = 'Tadas' WHERE nombre_tecnico IN ('tadas', 'TADAS', 'Tadas tecnico');
UPDATE partes SET nombre_tecnico = 'Enrique' WHERE nombre_tecnico IN ('enrique', 'ENRIQUE', 'Enrique tecnico');
UPDATE partes SET nombre_tecnico = 'Deve' WHERE nombre_tecnico IN ('deve', 'DEVE');

-- 5. Verificar resultado final
SELECT username, name, role FROM usuarios WHERE role = 'user' ORDER BY name;

-- 6. Ver nombres de técnicos en partes
SELECT DISTINCT nombre_tecnico FROM partes ORDER BY nombre_tecnico;
