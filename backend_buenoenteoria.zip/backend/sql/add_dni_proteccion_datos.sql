-- ===============================================
-- BeeSoftware - Añadir campos DNI y Protección de Datos
-- ===============================================
-- Este script añade dos nuevos campos a la tabla partes:
-- 1. dni_cliente: Para almacenar el DNI del cliente
-- 2. acepta_proteccion_datos: Para confirmar aceptación RGPD

USE ysqytyxn_ddbbMrClimaPartes;

-- Añadir columna DNI del cliente (si no existe)
ALTER TABLE partes 
ADD COLUMN dni_cliente VARCHAR(20) NULL 
AFTER cliente_email;

-- Añadir columna de aceptación de protección de datos (si no existe)
ALTER TABLE partes 
ADD COLUMN acepta_proteccion_datos BOOLEAN DEFAULT FALSE 
AFTER dni_cliente;

-- Verificar que las columnas se crearon correctamente
DESCRIBE partes;
