-- ===============================================
-- BeeSoftware - Script SQL para configurar roles
-- ===============================================
-- IMPORTANTE: Ejecuta este script en tu base de datos MySQL
-- Base de datos: beesoftware

USE beesoftware;

-- Asegurar que la columna 'role' existe en la tabla usuarios
ALTER TABLE usuarios 
ADD COLUMN IF NOT EXISTS role VARCHAR(20) NOT NULL DEFAULT 'user';

-- Asignar rol 'admin' a marcos y rafaelaadmin
UPDATE usuarios SET role = 'admin' WHERE username = 'marcos';
UPDATE usuarios SET role = 'admin' WHERE username = 'rafaelaadmin';

-- Asegurar que todos los demás usuarios tengan rol 'user'
UPDATE usuarios SET role = 'user' WHERE role IS NULL OR role = '';
UPDATE usuarios SET role = 'user' WHERE username NOT IN ('marcos', 'rafaelaadmin') AND role != 'user';

-- Verificar la configuración de roles
SELECT id, username, name, role FROM usuarios ORDER BY role DESC, username ASC;
