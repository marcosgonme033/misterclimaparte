-- ===============================================
-- BeeSoftware - Script SQL para crear tabla partes
-- ===============================================
-- IMPORTANTE: Ejecuta este script en tu base de datos MySQL
-- Base de datos: ysqytyxn_ddbbMrClimaPartes

USE ysqytyxn_ddbbMrClimaPartes;

-- Eliminar tabla si existe (cuidado: borra todos los datos)
-- DROP TABLE IF EXISTS partes;

-- Crear tabla partes
CREATE TABLE IF NOT EXISTS partes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  numero_parte VARCHAR(6) NOT NULL,
  aparato VARCHAR(255) NOT NULL,
  poblacion VARCHAR(255) NOT NULL,
  nombre_tecnico VARCHAR(255) NOT NULL,
  observaciones TEXT NULL,
  nota_parte VARCHAR(255) NULL,
  instrucciones_recibidas TEXT NULL,
  instrucciones_tecnico TEXT NULL,
  informe_tecnico TEXT NULL,
  fotos_json LONGTEXT NULL,
  firma_base64 LONGTEXT NULL,
  cliente_email VARCHAR(255) NULL,
  estado VARCHAR(50) NOT NULL DEFAULT 'inicial',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crear índices para optimización
CREATE INDEX idx_nombre_tecnico ON partes(nombre_tecnico);
CREATE INDEX idx_estado ON partes(estado);
CREATE INDEX idx_numero_parte ON partes(numero_parte);

-- Insertar parte de ejemplo
INSERT INTO partes (
  numero_parte,
  aparato,
  poblacion,
  nombre_tecnico,
  observaciones,
  estado
) VALUES 
(
  '100001',
  'Aire Acondicionado Split 3000 frigorías',
  'Madrid',
  'Marcos - BeeSoftware',
  'Parte de ejemplo para probar el sistema',
  'inicial'
);

-- Verificar que se creó correctamente
SELECT * FROM partes;

