-- Script para añadir índice único a numero_parte
-- Esto previene la creación de partes con números duplicados

USE beesoftware;

-- Verificar si hay duplicados existentes (opcional, para información)
SELECT numero_parte, COUNT(*) as cantidad
FROM partes
GROUP BY numero_parte
HAVING COUNT(*) > 1;

-- Si hay duplicados, deberás decidir cuál mantener antes de ejecutar el siguiente comando
-- Por ejemplo, puedes eliminar los duplicados manualmente o renumerarlos

-- Añadir índice único a numero_parte
ALTER TABLE partes
ADD UNIQUE KEY uk_partes_numero_parte (numero_parte);

-- Verificar que el índice se creó correctamente
SHOW INDEX FROM partes WHERE Key_name = 'uk_partes_numero_parte';
