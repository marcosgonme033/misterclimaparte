-- Migración: Añadir campo cliente_telefono a la tabla partes
-- Fecha: 2025-12-19
-- Descripción: Campo para almacenar el teléfono del cliente

ALTER TABLE partes 
ADD COLUMN IF NOT EXISTS cliente_telefono VARCHAR(30) NULL 
AFTER cliente_email;
